package com.example.odev_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
